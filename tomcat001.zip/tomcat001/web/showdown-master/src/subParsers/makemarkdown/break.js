showdown.subParser('makeMarkdown.break', function () {
  'use strict';

  return '  \n';
});
